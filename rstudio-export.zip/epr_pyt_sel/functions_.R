
# Create Founder Population:
createFounderPopulation <- function(nInd, nChr, segSites, bp, ploidy) {
  founderPop <- runMacs2(nInd = nInd, nChr = nChr, segSites = segSites, bp = bp, ploidy = ploidy)
  return(founderPop)
}


# Set Simulation Parameters
setSimParam <- function(founderPop, minQtlPerChr) {
  SP <- SimParam$new(founderPop)$restrSegSites(minQtlPerChr = minQtlPerChr)
  # SP$setSexes("yes_sys")
  return(SP)
}


# create a base population
createBasePopulation <- function(founderPop, SP, means_trait, vars_traits, cors_traits) {#h2S_traits
  #SP$setSexes("yes_sys")
  SP$addTraitA(nQtlPerChr = 1000, mean = means_trait, var = vars_traits, corA = cors_traits)
  #SP$setVarE(h2S_traits)
  basepop <- newPop(founderPop, SP)
  return(basepop)
}

#breeding design

performBreedingDesign <- function(basepop, nFemale, nMale, nCrosses, nProgeny, simParam, keepParents) {
  F1 <- selectCross(basepop,nInd=14 , nCrosses = nCrosses, nProgeny = nProgeny, simParam = simParam, balance = TRUE) #nFemale = nFemale, nMale = nMale
  DH <- makeDH(F1, nDH = 2,  keepParents = keepParents, simParam = simParam)
  parents <- cbind(F1@mother, F1@father)
  return(list(F1 = F1, DH = DH, parents = parents))
}
# 
# 
# #create intercrop trial
# createIntercropTrial <- function(speciesA, speciesB, varE, reps, traitA, traitB, combinations) {
#   output = list(speciesA = speciesA, speciesB = speciesB, combinations_data = NULL)
#   
#   if (combinations == "ALL") {
#     combinations = expand.grid(idA = speciesA@id, idB = speciesB@id)
#   }
#   
#   combination_id = paste(combinations$idA, combinations$idB, sep = "_")
#   
#   gv_IC = (speciesA@gv[match(combinations$idA, speciesA@id), traitA] +
#              speciesB@gv[match(combinations$idB, speciesB@id), traitB]) / 2
#   pheno_IC = gv_IC + rnorm(nrow(combinations), sd = sqrt(varE / reps))
#   
#   combinations_data = data.frame(
#     combination_id = combination_id,
#     gv_IC = gv_IC,
#     pheno_IC = pheno_IC,
#     idA = speciesA@id,
#     idB = speciesB@id
#   )
#   
#   output$combinations_data = combinations_data
#   
#   class(output) = "intercrop_trial"
#   return(output)
# }
# 
# 


#select top performers
selectTopPerformers <- function(data, n) {
  top_performers <- data %>% arrange(desc(pheno_IC)) %>% head(n = n)
  return(top_performers)
}



# Extract Species ID
extractSpeciesIDs <- function(data, n) {
  speciesIDs <- unique(data$idA) %>% head(n = n)
  return(speciesIDs)
}



#Create New Intercrop Trial Based on Selected IDs

# createIntercropTrialWithSelectedIDs <- function(speciesA, speciesB, varE, reps,traitA, traitB, selectedIDs) {
#   # Create combinations using selected IDs
#   combinations <- expand.grid(idA = selectedIDs@idA, idB = selectedIDs@idB)
#   
#   output = list(speciesA = speciesA, speciesB = speciesB, combinations_data = NULL)
#   
#   combination_id = paste(combinations$idA, combinations$idB, sep = "_")
#   
#   gv_IC = (speciesA@gv[match(combinations$idA, speciesA@id), traitA] +
#              speciesB@gv[match(combinations$idB, speciesB@id), traitB]) / 2
#   pheno_IC = gv_IC + rnorm(nrow(combinations), sd = sqrt(varE / reps))
#   
#   combinations_data = data.frame(
#     combination_id = combination_id,
#     gv_IC = gv_IC,
#     pheno_IC = pheno_IC,
#     idA = speciesA@id,
#     idB = speciesB@id
#   )
#   
#   output$combinations_data = combinations_data
#   
#   class(output) = "intercrop_trial"
#   return(output)
# }

# 
# createIntercropTrial <- function(speciesA, speciesB, varE, reps, traitA, traitB, combinations, h2 ) {
#   output = list(speciesA = speciesA, speciesB = speciesB, combinations_data = NULL)
#   
#   if (combinations == "ALL") {
#     combinations = expand.grid(idA = speciesA@id, idB = speciesB@id)
#   }
#   
#   combination_id = paste(combinations$idA, combinations$idB, sep = "_")
#   
#   gv_IC = (speciesA@gv[match(combinations$idA, speciesA@id), traitA] +
#              speciesB@gv[match(combinations$idB, speciesB@id), traitB]) / 2
#   
#   # Calculate phenotypic variance and genetic variance
#   phenotypic_var = varE / reps
#   genetic_var = h2 * phenotypic_var
#   
#   # Generate environmental values and error terms
#   env_values = rnorm(nrow(combinations), sd = sqrt(varE / reps))
#   error_terms = rnorm(nrow(combinations), sd = sqrt((1 - h2) * phenotypic_var))
#   
#   # Calculate phenotypic values
#   pheno_IC = gv_IC + env_values + error_terms
#   
#   combinations_data = data.frame(
#     combination_id = combination_id,
#     gv_IC = gv_IC,
#     pheno_IC = pheno_IC,
#     idA = speciesA@id,
#     idB = speciesB@id
#   )
#   
#   output$combinations_data = combinations_data
#   return(output)
# }

createIntercropTrial <- function(speciesA, speciesB, reps, traitA, traitB, combinations, h2 ) { #varE,
  output = list(speciesA = speciesA, speciesB = speciesB, combinations_data = NULL)
  
  if (combinations == "ALL") {
    combinations = expand.grid(idA = speciesA@id, idB = speciesB@id)
  }
  
  combination_id = paste(combinations$idA, combinations$idB, sep = "_")
  
  gv_IC = (speciesA@gv[match(combinations$idA, speciesA@id), traitA] +
             speciesB@gv[match(combinations$idB, speciesB@id), traitB]) / 2
  
  # Calculate phenotypic variance and genetic variance
  #phenotypic_var = ((var(gv_IC)/h2)*reps)/ reps
  #genetic_var = h2 * phenotypic_var
  
  # Generate environmental values and error terms
  #env_values = rnorm(nrow(combinations), sd = sqrt(varE ))
  #error_terms = rnorm(nrow(combinations), sd = sqrt((1 - h2) * (varE/reps)))
  
  # error_terms = rnorm(nrow(combinations), sd = sqrt((var(gv_IC)/h2)*reps)) #original from calcuations from me 
  
  varA  = vars_traits #changed to initial genetic variance is the variance of the intercrop genetic values
  varE  = vars_traits*reps* ((1 - h2) / h2) # environmental variance derived from heritability
  
  error = rnorm(nrow(combinations), sd = sqrt(varE/reps))
  
  pheno_IC = gv_IC + error
  # This formula assumes that each individual plant's phenotype is affected by its own unique environmental variance, and the environmental variance is inversely proportional to the heritability and directly proportional to the number of replicates. It is commonly used when modeling individual measurements rather than mean values derived from replicated trials
  
  #This assumes that you want the error variance to be proportional to the genetic variance divided by heritability and the number of replicates. This would be correct if you're trying to simulate the phenotypic outcome as it would be estimated in a replicated trial, where the environmental variance is reduced by the number of replicates.
  
  
  
  
  
  
  #error_terms = rnorm(nrow(combinations), sd = sqrt(var(gv_IC)*(1 - h2)/reps))  #2#########################################
  
  
  
  
  
  # 	The standard deviation for the error terms is computed as the square root of the genetic variance times 1−ℎ21−h2 divided by the number of replicates (reps). The 1−ℎ21−h2 term represents the environmental variance as a proportion of the total phenotypic variance, assuming that h2 is the narrow-sense heritability.
  #  	The error_terms are added directly to gv_IC without additional scaling
  
  
  
  
  # Calculate phenotypic values
  #pheno_IC = gv_IC + env_values + error_terms
  
  
  
  #error_terms = rnorm(nrow(combinations), sd = sqrt(var(gv_IC)/h2))
  
  #pheno_IC = gv_IC + error_terms#/sqrt(reps)  # if you are aiming to simulate the phenotype for each individual plant (which might not be averaged over replicates), then you would not divide by reps when generating the error_terms, and the calculation of the phenotype would indeed include the division by sqrt(reps) to reflect the averaging of replicates in the phenotype observation
  
  combinations_data = data.frame(
    combination_id = combination_id,
    gv_IC = gv_IC,
    pheno_IC = pheno_IC,
    idA = speciesA@id,
    idB = speciesB@id
  )
  
  output$combinations_data = combinations_data
  return(output)
}


