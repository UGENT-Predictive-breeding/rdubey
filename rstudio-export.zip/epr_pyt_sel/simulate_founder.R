# 
# g_corr <- scenario1$g_corr
# h2_pyt <- scenario1$h2_pyt
# h2_ayt <- scenario1$h2_ayt
# h2_eyt <- scenario1$h2_eyt
# plantsPerRow <- scenario1$plantsPerRow
# nRowFn <- scenario1$nRowFn
# nCrosses_faba <- scenario1$nCrosses_faba
# nCrosses_trit <- scenario1$nCrosses_trit
# nProgenyF1 <- scenario1$nProgenyF1
# nselect_F3 <- scenario1$nselect_F3
# nselect_F4 <- scenario1$nselect_F4
# nselect_F5 <- scenario1$nselect_F5
# ncomb_ayt <- scenario1$ncomb_ayt
# ncomb_eyt <- scenario1$ncomb_eyt
# nreps_pyt <- scenario1$nreps_pyt
# nreps_ayt <- scenario1$nreps_ayt
# nreps_eyt <- scenario1$nreps_eyt
# path_gv <- scenario1$path_gv
# path_pheno <- scenario1$path_pheno
# path_varP <- scenario1$path_varP
# path_varG <- scenario1$path_varG
# selection_stage <- scenario1$selection_stage
# 
# 
# 
# 
# 
# 
# 



means_trait=c(0,0) #trait mean
vars_traits= c(1,1) #trait var 
cors_traits=matrix(data=g_corr, byrow = TRUE,nrow=2,ncol=2)

# Create Founder Population for Faba
founderPop_faba = createFounderPopulation(nInd=100, nChr=1,segSites =1000,bp= 1.1e+9,ploidy= 2L)
SP_faba = setSimParam(founderPop_faba, 1000)
basepop_faba = createBasePopulation(founderPop_faba, SP_faba, means_trait, vars_traits, cors_traits)
Par_faba_initial = basepop_faba

# Create Founder Population for Triticale
founderPop_trit = createFounderPopulation(nInd=100,nChr= 1,segSites= 1000,bp= 9.9e+8,ploidy= 2L)
SP_trit = setSimParam(founderPop_trit, 1000)
basepop_trit = createBasePopulation(founderPop_trit, SP_trit, means_trait, vars_traits, cors_traits)
Par_trit_initial = basepop_trit

