library(data.table)
library(ggplot2)
library(dplyr)
library(gridExtra)


setwd("/data/home/rdubey/MIB approach/MIB/dh_breeding/Selection_stage/dh_pyt_sel/")

breeding_cycles <- 1:20
path_output= setwd(getwd())

# Define a list of folder paths for different scenarios
folder_path <- c(
  corr3_0.5 = "output_dh_pyt/pyt_corr0.3_her0.5/gv",
  corr3_0.3 = "output_dh_pyt/pyt_corr0.3_her0.3/gv",
  corr3_0.9 = "output_dh_pyt/pyt_corr0.3_her0.9/gv",
  corr5_0.5 = "output_dh_pyt/pyt_corr0.5_her0.5/gv",
  corr5_0.3 = "output_dh_pyt/pyt_corr0.5_her0.3/gv",
  corr5_0.9 = "output_dh_pyt/pyt_corr0.5_her0.9/gv",
  corr9_0.5 = "output_dh_pyt/pyt_corr0.9_her0.5/gv",
  corr9_0.3 = "output_dh_pyt/pyt_corr0.9_her0.3/gv",
  corr9_0.9 = "output_dh_pyt/pyt_corr0.9_her0.9/gv"
)


# Function to process a scenario folder
process_scenario <- function(folder_path) {
  file_list <- list.files(path = folder_path, pattern = "\\.csv$", full.names = TRUE, recursive = TRUE)
  
  # Initialize empty lists to store individual data.frames for different columns
  
  eyt_list <- list()
  
  # Iterate through each file and extract the 'PYT_gv_ic', 'AYT', and 'EYT' columns
  for (file in file_list) {
    dt <- fread(file)
    
    if ('EYT_gv_ic' %in% colnames(dt)) {
      eyt_list[[file]] <- dt[, .(EYT_gv_ic)]
    }
  }
  
  
  result_eyt_dt <- data.frame(eyt_list)
  eyt_GV <- rowMeans(result_eyt_dt)
  
  return(list( eyt_GV = eyt_GV))
}


results <- lapply(folder_path, process_scenario)

#Function to extract data and create a dataframe
extract_and_combine <- function(prefix, suffixes, results) {
  data_list <- lapply(suffixes, function(suffix) {
    eyt_data <- results[[paste0(prefix, "_", suffix)]]$eyt_GV
    data.frame(cycle = breeding_cycles, value = eyt_data, corr = paste0(prefix, "_", suffix))
  })
  do.call(rbind, data_list)
}

# Extract and combine data
df_eyt_corr3 <- extract_and_combine("corr3", c("0.5", "0.3", "0.9"), results)
df_eyt_corr5 <- extract_and_combine("corr5", c("0.5", "0.3", "0.9"), results)
df_eyt_corr9 <- extract_and_combine("corr9", c("0.5", "0.3", "0.9"), results)

combined_eyt_plot <- grid.arrange(
  ggplot(df_eyt_corr3, aes(x = cycle, y = value, group = corr, color = as.factor(gsub(".*_", "", corr)))) +
    geom_line(size = 0.75) +
    labs(
      x = "Breeding Cycle",
      y = "Intercrop GV", color = "Trait heritability"
    ) +
    scale_color_manual(values = c("0.5" = "red", "0.3" = "blue", "0.9" = "green")) +
    theme_minimal() +
    coord_cartesian(ylim = c(1.5, 3)) +
    ggtitle("corr0.3") +
    theme(legend.position = "bottom"),
  
  ggplot(df_eyt_corr5, aes(x = cycle, y = value, group = corr, color = as.factor(gsub(".*_", "", corr)))) +
    geom_line(size = 0.75) +
    labs(
      x = "Breeding Cycle",
      y = "Intercrop GV", color = "Trait heritability"
    ) +
    scale_color_manual(values = c("0.5" = "red", "0.3" = "blue", "0.9" = "green")) +
    theme_minimal() +
    coord_cartesian(ylim = c(1.5, 3)) +
    ggtitle("corr0.5") +
    theme(legend.position = "bottom"),
  
  ggplot(df_eyt_corr9, aes(x = cycle, y = value, group = corr, color = as.factor(gsub(".*_", "", corr)))) +
    geom_line(size = 0.75) +
    labs(
      x = "Breeding Cycle",
      y = "Intercrop GV",
      color = "Trait heritability"
    ) +
    scale_color_manual(values = c("0.5" = "red", "0.3" = "blue", "0.9" = "green")) +
    theme_minimal() +
    coord_cartesian(ylim = c(1.5, 3)) +
    ggtitle(" corr0.9") +
    theme(legend.position = "bottom"),
  
  ncol = 3
)

#####################################################################################################
breeding_cycles <- 1:20
path_output= setwd(getwd())
# Define a list of folder paths for different scenarios
folder_path <- c(
  corr3_0.5 = "output_dh_pyt/ayt_corr0.3_her0.5/gv",
  corr3_0.3 = "output_dh_pyt/ayt_corr0.3_her0.3/gv",
  corr3_0.9 = "output_dh_pyt/ayt_corr0.3_her0.9/gv",
  corr5_0.5 = "output_dh_pyt/ayt_corr0.5_her0.5/gv",
  corr5_0.3 = "output_dh_pyt/ayt_corr0.5_her0.3/gv",
  corr5_0.9 = "output_dh_pyt/ayt_corr0.5_her0.9/gv",
  corr9_0.5 = "output_dh_pyt/ayt_corr0.9_her0.5/gv",
  corr9_0.3 = "output_dh_pyt/ayt_corr0.9_her0.3/gv",
  corr9_0.9 = "output_dh_pyt/ayt_corr0.9_her0.9/gv"
)


# Function to process a scenario folder
process_scenario <- function(folder_path) {
  file_list <- list.files(path = folder_path, pattern = "\\.csv$", full.names = TRUE, recursive = TRUE)
  
  # Initialize empty lists to store individual data.frames for different columns
  
  eyt_list <- list()
  
  # Iterate through each file and extract the 'PYT_gv_ic', 'AYT', and 'EYT' columns
  for (file in file_list) {
    dt <- fread(file)
    
    if ('EYT_gv_ic' %in% colnames(dt)) {
      eyt_list[[file]] <- dt[, .(EYT_gv_ic)]
    }
  }
  
  
  result_eyt_dt <- data.frame(eyt_list)
  eyt_GV <- rowMeans(result_eyt_dt)
  
  return(list( eyt_GV = eyt_GV))
}


results <- lapply(folder_path, process_scenario)

#Function to extract data and create a dataframe
extract_and_combine <- function(prefix, suffixes, results) {
  data_list <- lapply(suffixes, function(suffix) {
    eyt_data <- results[[paste0(prefix, "_", suffix)]]$eyt_GV
    data.frame(cycle = breeding_cycles, value = eyt_data, corr = paste0(prefix, "_", suffix))
  })
  do.call(rbind, data_list)
}

# Extract and combine data
df_eyt_corr3 <- extract_and_combine("corr3", c("0.5", "0.3", "0.9"), results)
df_eyt_corr5 <- extract_and_combine("corr5", c("0.5", "0.3", "0.9"), results)
df_eyt_corr9 <- extract_and_combine("corr9", c("0.5", "0.3", "0.9"), results)

combined_eyt_plot <- grid.arrange(
  ggplot(df_eyt_corr3, aes(x = cycle, y = value, group = corr, color = as.factor(gsub(".*_", "", corr)))) +
    geom_line(size = 0.75) +
    labs(
      x = "Breeding Cycle",
      y = "Intercrop GV", color = "Trait heritability"
    ) +
    scale_color_manual(values = c("0.5" = "red", "0.3" = "blue", "0.9" = "green")) +
    theme_minimal() +
    coord_cartesian(ylim = c(1.5, 3)) +
    ggtitle("corr0.3") +
    theme(legend.position = "bottom"),
  
  ggplot(df_eyt_corr5, aes(x = cycle, y = value, group = corr, color = as.factor(gsub(".*_", "", corr)))) +
    geom_line(size = 0.75) +
    labs(
      x = "Breeding Cycle",
      y = "Intercrop GV", color = "Trait heritability"
    ) +
    scale_color_manual(values = c("0.5" = "red", "0.3" = "blue", "0.9" = "green")) +
    theme_minimal() +
    coord_cartesian(ylim = c(1.5, 3)) +
    ggtitle("corr0.5") +
    theme(legend.position = "bottom"),
  
  ggplot(df_eyt_corr9, aes(x = cycle, y = value, group = corr, color = as.factor(gsub(".*_", "", corr)))) +
    geom_line(size = 0.75) +
    labs(
      x = "Breeding Cycle",
      y = "Intercrop GV",
      color = "Trait heritability"
    ) +
    scale_color_manual(values = c("0.5" = "red", "0.3" = "blue", "0.9" = "green")) +
    theme_minimal() +
    coord_cartesian(ylim = c(1.5, 3)) +
    ggtitle(" corr0.9") +
    theme(legend.position = "bottom"),
  
  ncol = 3
)


################################################################################################################################################

breeding_cycles <- 1:20
path_output= setwd(getwd())
# Define a list of folder paths for different scenarios
folder_path <- c(
  corr3_0.5 = "output_dh_pyt/eyt_corr0.3_her0.5/gv",
  corr3_0.3 = "output_dh_pyt/eyt_corr0.3_her0.3/gv",
  corr3_0.9 = "output_dh_pyt/eyt_corr0.3_her0.9/gv",
  corr5_0.5 = "output_dh_pyt/eyt_corr0.5_her0.5/gv",
  corr5_0.3 = "output_dh_pyt/eyt_corr0.5_her0.3/gv",
  corr5_0.9 = "output_dh_pyt/eyt_corr0.5_her0.9/gv",
  corr9_0.5 = "output_dh_pyt/eyt_corr0.9_her0.5/gv",
  corr9_0.3 = "output_dh_pyt/eyt_corr0.9_her0.3/gv",
  corr9_0.9 = "output_dh_pyt/eyt_corr0.9_her0.9/gv"
)


# Function to process a scenario folder
process_scenario <- function(folder_path) {
  file_list <- list.files(path = folder_path, pattern = "\\.csv$", full.names = TRUE, recursive = TRUE)
  
  # Initialize empty lists to store individual data.frames for different columns
  
  eyt_list <- list()
  
  # Iterate through each file and extract the 'PYT_gv_ic', 'AYT', and 'EYT' columns
  for (file in file_list) {
    dt <- fread(file)
    
    if ('EYT_gv_ic' %in% colnames(dt)) {
      eyt_list[[file]] <- dt[, .(EYT_gv_ic)]
    }
  }
  
  
  result_eyt_dt <- data.frame(eyt_list)
  eyt_GV <- rowMeans(result_eyt_dt)
  
  return(list( eyt_GV = eyt_GV))
}


results <- lapply(folder_path, process_scenario)

#Function to extract data and create a dataframe
extract_and_combine <- function(prefix, suffixes, results) {
  data_list <- lapply(suffixes, function(suffix) {
    eyt_data <- results[[paste0(prefix, "_", suffix)]]$eyt_GV
    data.frame(cycle = breeding_cycles, value = eyt_data, corr = paste0(prefix, "_", suffix))
  })
  do.call(rbind, data_list)
}

# Extract and combine data
df_eyt_corr3 <- extract_and_combine("corr3", c("0.5", "0.3", "0.9"), results)
df_eyt_corr5 <- extract_and_combine("corr5", c("0.5", "0.3", "0.9"), results)
df_eyt_corr9 <- extract_and_combine("corr9", c("0.5", "0.3", "0.9"), results)

combined_eyt_plot <- grid.arrange(
  ggplot(df_eyt_corr3, aes(x = cycle, y = value, group = corr, color = as.factor(gsub(".*_", "", corr)))) +
    geom_line(size = 0.75) +
    labs(
      x = "Breeding Cycle",
      y = "Intercrop GV", color = "Trait heritability"
    ) +
    scale_color_manual(values = c("0.5" = "red", "0.3" = "blue", "0.9" = "green")) +
    theme_minimal() +
    coord_cartesian(ylim = c(1.5, 3)) +
    ggtitle("corr0.3") +
    theme(legend.position = "bottom"),
  
  ggplot(df_eyt_corr5, aes(x = cycle, y = value, group = corr, color = as.factor(gsub(".*_", "", corr)))) +
    geom_line(size = 0.75) +
    labs(
      x = "Breeding Cycle",
      y = "Intercrop GV", color = "Trait heritability"
    ) +
    scale_color_manual(values = c("0.5" = "red", "0.3" = "blue", "0.9" = "green")) +
    theme_minimal() +
    coord_cartesian(ylim = c(1.5, 3)) +
    ggtitle("corr0.5") +
    theme(legend.position = "bottom"),
  
  ggplot(df_eyt_corr9, aes(x = cycle, y = value, group = corr, color = as.factor(gsub(".*_", "", corr)))) +
    geom_line(size = 0.75) +
    labs(
      x = "Breeding Cycle",
      y = "Intercrop GV",
      color = "Trait heritability"
    ) +
    scale_color_manual(values = c("0.5" = "red", "0.3" = "blue", "0.9" = "green")) +
    theme_minimal() +
    coord_cartesian(ylim = c(1.5, 3)) +
    ggtitle(" corr0.9") +
    theme(legend.position = "bottom"),
  
  ncol = 3
)





####################################################################################################
path_output= setwd(getwd())
# Define a list of folder paths for different scenarios
folder_path_varG <- c(
  corr3_0.5 = "output_dh_pyt/ayt_corr0.3_her0.5/varG",
  corr3_0.3 = "output_dh_pyt/ayt_corr0.3_her0.3/varG",
  corr3_0.9 = "output_dh_pyt/ayt_corr0.3_her0.9/varG",
  corr5_0.5 = "output_dh_pyt/ayt_corr0.5_her0.5/varG",
  corr5_0.3 = "output_dh_pyt/ayt_corr0.5_her0.3/varG",
  corr5_0.9 = "output_dh_pyt/ayt_corr0.5_her0.9/varG",
  corr9_0.5 = "output_dh_pyt/ayt_corr0.9_her0.5/varG",
  corr9_0.3 = "output_dh_pyt/ayt_corr0.9_her0.3/varG",
  corr9_0.9 = "output_dh_pyt/ayt_corr0.9_her0.9/varG"
)

process_scenario_varG <- function(folder_path) {
  file_list_varG <- list.files(path = folder_path_varG, pattern = "\\.csv$", full.names = TRUE, recursive = TRUE)
  
  # Initialize empty lists to store individual data.frames for different columns
  
  eyt_varG_list <- list()
  
  # Iterate through each file and extract the 'PYT_gv_ic', 'AYT', and 'EYT' columns
  for (file in file_list_varG) {
    dt <- fread(file)
    
    if ('EYT_varG_ic' %in% colnames(dt)) {
      eyt_varG_list[[file]] <- dt[, .(EYT_varG_ic)]
    }
  }
  
  
  result_eytvarG_dt <- data.frame(eyt_varG_list)
  eyt_varG <- rowMeans(result_eytvarG_dt)
  
  return(list( eyt_varG = eyt_varG))
}

results_var <- lapply(folder_path_varG, process_scenario_varG)

#Function to extract data and create a dataframe
extract_and_combine_varG <- function(prefix, suffixes, results) {
  data_list <- lapply(suffixes, function(suffix) {
    eyt_data <- results[[paste0(prefix, "_", suffix)]]$eyt_varG
    data.frame(cycle = breeding_cycles, value = eyt_data, corr = paste0(prefix, "_", suffix))
  })
  do.call(rbind, data_list)
}

# Extract and combine data
df_eyt_corr3_var <- extract_and_combine_varG("corr3", c("0.5", "0.3", "0.9"), results_var)
df_eyt_corr5_var <- extract_and_combine_varG("corr5", c("0.5", "0.3", "0.9"), results_var)
df_eyt_corr9_var <- extract_and_combine_varG("corr9", c("0.5", "0.3", "0.9"), results_var)

combined_eyt_plot_varG <- grid.arrange(
  ggplot(df_eyt_corr3_var, aes(x = cycle, y = value, group = corr, color = as.factor(gsub(".*_", "", corr)))) +
    geom_line(size = 0.75) +
    labs(
      x = "Breeding Cycle",
      y = "Intercrop varG", color = "Trait heritability"
    ) +
    scale_color_manual(values = c("0.5" = "red", "0.3" = "blue", "0.9" = "green")) +
    theme_minimal() +
    #coord_cartesian(ylim = c(1.5, 3)) +
    ggtitle("corr0.3") +
    theme(legend.position = "bottom"),
  
  ggplot(df_eyt_corr5_var, aes(x = cycle, y = value, group = corr, color = as.factor(gsub(".*_", "", corr)))) +
    geom_line(size = 0.75) +
    labs(
      x = "Breeding Cycle",
      y = "Intercrop varG", color = "Trait heritability"
    ) +
    scale_color_manual(values = c("0.5" = "red", "0.3" = "blue", "0.9" = "green")) +
    theme_minimal() +
    #coord_cartesian(ylim = c(1.5, 3)) +
    ggtitle("corr0.5") +
    theme(legend.position = "bottom"),
  
  ggplot(df_eyt_corr9_var, aes(x = cycle, y = value, group = corr, color = as.factor(gsub(".*_", "", corr)))) +
    geom_line(size = 0.75) +
    labs(
      x = "Breeding Cycle",
      y = "Intercrop varG",
      color = "Trait heritability"
    ) +
    scale_color_manual(values = c("0.5" = "red", "0.3" = "blue", "0.9" = "green")) +
    theme_minimal() +
    #coord_cartesian(ylim = c(1.5, 3)) +
    ggtitle(" corr0.9") +
    theme(legend.position = "bottom"),
  
  ncol = 3
)

