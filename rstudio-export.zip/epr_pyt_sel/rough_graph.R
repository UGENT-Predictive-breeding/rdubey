# Set the path to your folder
folder_path <- "/data/home/rdubey/MIB approach/MIB/dh_breeding/Selection_stage/dh_pyt_sel/output/"

# Get a list of files in the folder
all_folders <- list.dirs(path = folder_path, recursive = FALSE,full.names = TRUE)


result_list <- list()

for (folder in all_folders) {
  # Construct the path to the 'gv' folder within each main folder
  gv_folder_path <- file.path(folder, "gv")
  
  # Get a list of Excel files within the 'gv' folder
  file_list <- list.files(path = gv_folder_path, pattern = "\\.csv$", full.names = TRUE)
  
  # Initialize a list to store 'EYT_gv_ic' columns for each Excel file
  eyt_list <- list()
  
  # Iterate through each Excel file and extract 'EYT_gv_ic' column
  for (file in file_list) {
    dt <- fread(file)
    
    if ('EYT_gv_ic' %in% colnames(dt)) {
      eyt_list[[file]] <- dt[, .(EYT_gv_ic)]
    }
  }
  
  # Combine the 'EYT_gv_ic' columns into a data frame
  result_eyt_dt <- data.frame(eyt_list)
  
  # Calculate row means and store them in the result list
  result_list[[folder]] <- rowMeans(result_eyt_dt)
}

# Combine the results into a final data frame
final_result <- data.frame(result_list)
plot(final_result)
