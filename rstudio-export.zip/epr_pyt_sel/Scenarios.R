
# Define different parameters for scenarios

#Selection at PYT stage

scenarios <- list(
  #pyt_corr0.3
  scenario1 <- list(
    output_name= "pyt_corr0.3_her0.3",
    selection_stage= "pyt",
    g_corr = c(1.0, 0.3, 0.3, 1.0),
    h2_pyt = 0.1,
    h2_ayt = 0.2,
    h2_eyt = 0.3,
    
    plantsPerRow = 10,
    nRowFn=5  ,
    nCrosses_faba = 14,
    nCrosses_trit = 14,
    nProgenyF1 = 1,
    nselect_F3 = 10,
    nselect_F4 = 5,
    nselect_F5 = 2,
    ncomb_ayt = 144 ,
    ncomb_eyt = 36,
    nreps_pyt = 1 , 
    nreps_ayt = 2 ,  
    nreps_eyt = 4   
    
  ),


  scenario2 <- list(
    output_name= "pyt_corr0.3_her0.5",
    selection_stage= "pyt",
    g_corr = c(1.0, 0.3, 0.3, 1.0),
    h2_pyt = 0.2,
    h2_ayt = 0.3,
    h2_eyt = 0.5,
    plantsPerRow = 10,
    nRowFn=5  ,
    nCrosses_faba = 14,
    nCrosses_trit = 14,
    nProgenyF1 = 1,
    nselect_F3 = 10,
    nselect_F4 = 5,
    nselect_F5 = 2,
    ncomb_ayt = 144 ,
    ncomb_eyt = 36,
    nreps_pyt = 1 , 
    nreps_ayt = 2 ,  
    nreps_eyt = 4   
    
  ),


  scenario3 <- list(
    output_name= "pyt_corr0.3_her0.9",
    selection_stage= "pyt",
    g_corr = c(1.0, 0.3, 0.3, 1.0),
    h2_pyt = 0.3,
    h2_ayt = 0.5,
    h2_eyt = 0.9,
    plantsPerRow = 10,
    nRowFn=5  ,
    nCrosses_faba = 14,
    nCrosses_trit = 14,
    nProgenyF1 = 1,
    nselect_F3 = 10,
    nselect_F4 = 5,
    nselect_F5 = 2,
    ncomb_ayt = 144 ,
    ncomb_eyt = 36,
    nreps_pyt = 1 , 
    nreps_ayt = 2 ,  
    nreps_eyt = 4   
    
  ),




  #pytcorr0.5


  scenario4 <- list(
    output_name= "pyt_corr0.5_her0.3",
    selection_stage= "pyt",
    g_corr = c(1.0, 0.5, 0.5, 1.0),
    h2_pyt = 0.1,
    h2_ayt = 0.2,
    h2_eyt = 0.3,
    plantsPerRow = 10,
    nRowFn=5  ,
    nCrosses_faba = 14,
    nCrosses_trit = 14,
    nProgenyF1 = 1,
    nselect_F3 = 10,
    nselect_F4 = 5,
    nselect_F5 = 2,
    ncomb_ayt = 144 ,
    ncomb_eyt = 36,
    nreps_pyt = 1 , 
    nreps_ayt = 2 ,  
    nreps_eyt = 4   
    
  ),


  scenario5 <- list(
    output_name= "pyt_corr0.5_her0.5",
    selection_stage= "pyt",
    g_corr = c(1.0, 0.5, 0.5, 1.0),
    h2_pyt = 0.2,
    h2_ayt = 0.3,
    h2_eyt = 0.5,
    plantsPerRow = 10,
    nRowFn=5  ,
    nCrosses_faba = 14,
    nCrosses_trit = 14,
    nProgenyF1 = 1,
    nselect_F3 = 10,
    nselect_F4 = 5,
    nselect_F5 = 2,
    ncomb_ayt = 144 ,
    ncomb_eyt = 36,
    nreps_pyt = 1 , 
    nreps_ayt = 2 ,  
    nreps_eyt = 4   
    
  ),


  scenario6 <- list(
    output_name= "pyt_corr0.5_her0.9",
    selection_stage= "pyt",
    g_corr = c(1.0, 0.5, 0.5, 1.0),
    h2_pyt = 0.3,
    h2_ayt = 0.5,
    h2_eyt = 0.9,
    plantsPerRow = 10,
    nRowFn=5  ,
    nCrosses_faba = 14,
    nCrosses_trit = 14,
    nProgenyF1 = 1,
    nselect_F3 = 10,
    nselect_F4 = 5,
    nselect_F5 = 2,
    ncomb_ayt = 144 ,
    ncomb_eyt = 36,
    nreps_pyt = 1 , 
    nreps_ayt = 2 ,  
    nreps_eyt = 4   
    
  ),


  #pytcorr0.9



  scenario7 <- list(
    output_name= "pyt_corr0.9_her0.3",
    selection_stage= "pyt",
    g_corr = c(1.0, 0.9, 0.9, 1.0),
    h2_pyt = 0.1,
    h2_ayt = 0.2,
    h2_eyt = 0.3,
    plantsPerRow = 10,
    nRowFn=5  ,
    nCrosses_faba = 14,
    nCrosses_trit = 14,
    nProgenyF1 = 1,
    nselect_F3 = 10,
    nselect_F4 = 5,
    nselect_F5 = 2,
    ncomb_ayt = 144 ,
    ncomb_eyt = 36,
    nreps_pyt = 1 , 
    nreps_ayt = 2 ,  
    nreps_eyt = 4   
    
  ),


  scenario8 <- list(
    output_name= "pyt_corr0.9_her0.5",
    selection_stage= "pyt",
    g_corr = c(1.0, 0.9, 0.9, 1.0),
    h2_pyt = 0.2,
    h2_ayt = 0.3,
    h2_eyt = 0.5,
    plantsPerRow = 10,
    nRowFn=5  ,
    nCrosses_faba = 14,
    nCrosses_trit = 14,
    nProgenyF1 = 1,
    nselect_F3 = 10,
    nselect_F4 = 5,
    nselect_F5 = 2,
    ncomb_ayt = 144 ,
    ncomb_eyt = 36,
    nreps_pyt = 1 , 
    nreps_ayt = 2 ,  
    nreps_eyt = 4   
    
  ),


  scenario9 <- list(
    output_name= "pyt_corr0.9_her0.9",
    selection_stage= "pyt",
    g_corr = c(1.0, 0.9, 0.9, 1.0),
    h2_pyt = 0.3,
    h2_ayt = 0.5,
    h2_eyt = 0.9,
    plantsPerRow = 10,
    nRowFn=5  ,
    nCrosses_faba = 14,
    nCrosses_trit = 14,
    nProgenyF1 = 1,
    nselect_F3 = 10,
    nselect_F4 = 5,
    nselect_F5 = 2,
    ncomb_ayt = 144 ,
    ncomb_eyt = 36,
    nreps_pyt = 1 , 
    nreps_ayt = 2 ,  
    nreps_eyt = 4   
    

  )


)
