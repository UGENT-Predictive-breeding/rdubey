

for(year in 1:9){
  
  cat("epr_breeding:", year, "of 9\n")
  
  # Stage 1 - Initial Crosses (Year 1)
  if(year <1){
    # Faba Bean: Random crosses for F1 generation
    F1_faba = randCross(pop = Par_faba_initial, nCrosses = nCrosses_faba, nProgeny = nProgenyF1, simParam = SP_faba)
    # Triticale: Random crosses for F1 generation
    F1_trit = randCross(pop = Par_trit_initial, nCrosses = nCrosses_trit, nProgeny = nProgenyF1, simParam = SP_trit)
  }
  
  # Stage 2 - F2 Generation (Year 2)
  if(year < 2){
    F2_faba = vector("list", nCrosses_faba)
    F2_trit = vector("list", nCrosses_trit)
    for(i in 1:nCrosses_faba){
      # Faba Bean: Selfing F1 and selecting individuals for F2
      F2_faba_i = self(F1_faba[i], nProgeny = nProgenyF2,simParam = SP_faba )
      F2_faba_i = setPheno(F2_faba_i, h2 = 0.1, reps = 1,simParam = SP_faba)
      F2_faba[[i]] = selectInd(F2_faba_i, nInd = nselect_F2,use="pheno",simParam = SP_faba)
    }
    for(i in 1:nCrosses_trit){
      # Triticale: Selfing F1 and selecting individuals for F2
      F2_trit_i = self(F1_trit[i], nProgeny = nProgenyF2, simParam = SP_trit)
      F2_trit_i = setPheno(F2_trit_i,h2 = 0.1, reps = 1, simParam = SP_trit)
      F2_trit[[i]] = selectInd(F2_trit_i, nInd = nselect_F2,use="pheno", simParam = SP_trit)
    }
  }
  
  # Stage 3 - F3 Generation (Year 3)
 
    if(year < 3){
      F3_faba = vector("list", nCrosses_faba) #selected plants from each plants
      F3_trit = vector("list", nCrosses_trit)
      
      for(i in 1:nCrosses_faba){ #loop over crosses
        rows_faba = nInd(F2_faba[[i]]) #Get the number of rows (individuals) per cross in F2
       
        F3_frows = vector("list",rows_faba) #Create a list to store rows in crosses
        F3pheno = numeric(rows_faba) #Create a numeric vector to store row phenotypes
        
      
        # Loop over rows in the cross
        for (j in 1:rows_faba) {
          F3_frows[[j]] = self(F2_faba[[i]][j], plantsPerRow, simParam = SP_faba)  # Generate F3 rows using  "self"
          F3pheno[j] = meanP(F3_frows[[j]])  # Calculate the mean phenotype for each row
        }
        
        # Select "nRowF3" F3 rows per cross based on descending order of mean phenotype
        take = order(F3pheno, decreasing = TRUE)[1:nRowF3] #nrowF3=10
        F3_frows = F3_frows[take]
        
        # Select "nSelF3" plants per selected F3 row
        for (j in 1:nRowF3) {
          F3_frows[[j]] = setPheno(F3_frows[[j]], h2=0.1, reps = 1, simParam = SP_faba)  # Set phenotype using some function "setPheno"
          F3_frows[[j]] = selectInd(F3_frows[[j]], nselect_F3,use="pheno", simParam = SP_faba)  # Select a specified number of plants per row
        }
        
        F3_faba[[i]] = mergePops(F3_frows)  # Merge the selected F3 rows to create the final population for the cross
      }
        
        
        
    ####

        for(i in 1:nCrosses_trit){ #loop over crosses
          rows_trit = nInd(F2_trit[[i]]) #Get the number of rows (individuals) per cross in F2
          
          F3_trows = vector("list",rows_trit) #Create a list to store rows in crosses
          F3pheno = numeric(rows_trit) #Create a numeric vector to store row phenotypes
          
          
          
          # Loop over rows in the cross
          for (j in 1:rows_trit) {
            F3_trows[[j]] = self(F2_trit[[i]][j], plantsPerRow, simParam = SP_trit)  # Generate F3 rows using  "self"
            F3pheno[j] = meanP(F3_trows[[j]])  # Calculate the mean phenotype for each row
          }
          
          # Select "nRowF3" F3 rows per cross based on descending order of mean phenotype
          take = order(F3pheno, decreasing = TRUE)[1:nRowF3] #nrowF3=10
          F3_trows = F3_trows[take]
          
          # Select "nSelF3" plants per selected F3 row
          for (j in 1:nRowF3) {
            F3_trows[[j]] = setPheno(F3_trows[[j]], h2=0.1, reps = 1, simParam = SP_trit)  # Set phenotype using some function "setPheno"
            F3_trows[[j]] = selectInd(F3_trows[[j]], nselect_F3,use="pheno", simParam = SP_trit)  # Select a specified number of plants per row
          }
          
          F3_trit[[i]] = mergePops(F3_trows)  # Merge the selected F3 rows to create the final population for the cross
        }
        
        
        
      }
    
   ####################### 
  
  if(year < 4){
    F4_faba = vector("list", nCrosses_faba) #selected plants from each plants
    F4_trit = vector("list", nCrosses_trit)
    
    for(i in 1:nCrosses_faba){ #loop over crosses
      rows_faba = nInd(F3_faba[[i]]) #Get the number of rows (individuals) per cross in F2
      
      F4_frows = vector("list",rows_faba) #Create a list to store rows in crosses
      F4pheno = numeric(rows_faba) #Create a numeric vector to store row phenotypes
      
      
      # Loop over rows in the cross
      for (j in 1:rows_faba) {
        F4_frows[[j]] = self(F3_faba[[i]][j], plantsPerRow, simParam = SP_faba)  # Generate F4 rows using  "self"
        F4pheno[j] = meanP(F4_frows[[j]])  # Calculate the mean phenotype for each row
      }
      
      # Select "nRowF4" F4 rows per cross based on descending order of mean phenotype
      take = order(F4pheno, decreasing = TRUE)[1:nRowF4] #nrowF4=10
      F4_frows = F4_frows[take]
      
      # Select "nSelF4" plants per selected F4 row
      for (j in 1:nRowF4) {
        F4_frows[[j]] = setPheno(F4_frows[[j]], h2=0.1, reps = 1, simParam = SP_faba)  # Set phenotype using some function "setPheno"
        F4_frows[[j]] = selectInd(F4_frows[[j]], nselect_F4,use="pheno", simParam = SP_faba)  # Select a specified number of plants per row
      }
      
      F4_faba[[i]] = mergePops(F4_frows)  # Merge the selected F4 rows to create the final population for the cross
    }
    
    
    
    ####
    
    for(i in 1:nCrosses_trit){ #loop over crosses
      rows_trit = nInd(F3_trit[[i]]) #Get the number of rows (individuals) per cross in F2
      
      F4_trows = vector("list",rows_trit) #Create a list to store rows in crosses
      F4pheno = numeric(rows_trit) #Create a numeric vector to store row phenotypes
      
      
      
      # Loop over rows in the cross
      for (j in 1:rows_trit) {
        F4_trows[[j]] = self(F3_trit[[i]][j], plantsPerRow, simParam = SP_trit)  # Generate F4 rows using  "self"
        F4pheno[j] = meanP(F4_trows[[j]])  # Calculate the mean phenotype for each row
      }
      
      # Select "nRowF4" F4 rows per cross based on descending order of mean phenotype
      take = order(F4pheno, decreasing = TRUE)[1:nRowF4] #nrowF4=10
      F4_trows = F4_trows[take]
      
      # Select "nSelF4" plants per selected F4 row
      for (j in 1:nRowF4) {
        F4_trows[[j]] = setPheno(F4_trows[[j]], h2=0.1, reps = 1, simParam = SP_trit)  # Set phenotype using some function "setPheno"
        F4_trows[[j]] = selectInd(F4_trows[[j]], nselect_F4,use="pheno", simParam = SP_trit)  # Select a specified number of plants per row
      }
      
      F4_trit[[i]] = mergePops(F4_trows)  # Merge the selected F4 rows to create the final population for the cross
    }
    
    
    
  }
  ################
  
  if(year < 5){
    F5_faba = vector("list", nCrosses_faba) #selected plants from each plants
    F5_trit = vector("list", nCrosses_trit)
    
    for(i in 1:nCrosses_faba){ #loop over crosses
      rows_faba = nInd(F4_faba[[i]]) #Get the number of rows (individuals) per cross in F2
      
      F5_frows = vector("list",rows_faba) #Create a list to store rows in crosses
      F5pheno = numeric(rows_faba) #Create a numeric vector to store row phenotypes
      
      
      # Loop over rows in the cross
      for (j in 1:rows_faba) {
        F5_frows[[j]] = self(F4_faba[[i]][j], plantsPerRow, simParam = SP_faba)  # Generate F5 rows using  "self"
        F5pheno[j] = meanP(F5_frows[[j]])  # Calculate the mean phenotype for each row
      }
      
      # Select "nRowF5" F5 rows per cross based on descending order of mean phenotype
      take = order(F5pheno, decreasing = TRUE)[1:nRowF5] #nrowF5=10
      F5_frows = F5_frows[take]
      
      # Select "nSelF5" plants per selected F5 row
      for (j in 1:nRowF5) {
        F5_frows[[j]] = setPheno(F5_frows[[j]], h2=0.1, reps = 1, simParam = SP_faba)  # Set phenotype using some function "setPheno"
        F5_frows[[j]] = selectInd(F5_frows[[j]], nselect_F5,use="pheno", simParam = SP_faba)  # Select a specified number of plants per row
      }
      
      F5_faba[[i]] = mergePops(F5_frows)  # Merge the selected F5 rows to create the final population for the cross
    }
    
    
    
    ####
    
    for(i in 1:nCrosses_trit){ #loop over crosses
      rows_trit = nInd(F4_trit[[i]]) #Get the number of rows (individuals) per cross in F2
      
      F5_trows = vector("list",rows_trit) #Create a list to store rows in crosses
      F5pheno = numeric(rows_trit) #Create a numeric vector to store row phenotypes
      
      
      
      # Loop over rows in the cross
      for (j in 1:rows_trit) {
        F5_trows[[j]] = self(F4_trit[[i]][j], plantsPerRow, simParam = SP_trit)  # Generate F5 rows using  "self"
        F5pheno[j] = meanP(F5_trows[[j]])  # Calculate the mean phenotype for each row
      }
      
      # Select "nRowF5" F5 rows per cross based on descending order of mean phenotype
      take = order(F5pheno, decreasing = TRUE)[1:nRowF5] #nrowF5=10
      F5_trows = F5_trows[take]
      
      # Select "nSelF5" plants per selected F5 row
      for (j in 1:nRowF5) {
        F5_trows[[j]] = setPheno(F5_trows[[j]], h2=0.1, reps = 1, simParam = SP_trit)  # Set phenotype using some function "setPheno"
        F5_trows[[j]] = selectInd(F5_trows[[j]], nselect_F5,use="pheno", simParam = SP_trit)  # Select a specified number of plants per row
      }
      
      F5_trit[[i]] = mergePops(F5_trows)  # Merge the selected F5 rows to create the final population for the cross
    }
    
    F5_trit=mergePops(F5_trit)
    F5_trit=setPheno(F5_trit, h2=0.1, reps=1, simParam = SP_trit)
    F5_trit= selectInd(F5_faba,nInd=28,trait=1, use="pheno"  ,selectTop = TRUE,returnPop = TRUE,simParam = SP_trit)
   
    
    
    F5_faba=mergePops(F5_faba)
    F5_faba=setPheno(F5_faba, h2=0.1, reps=1, simParam = SP_faba)
    F5_faba= selectInd(F5_faba,nInd=28,trait=1, use="pheno"  ,selectTop = TRUE,returnPop = TRUE,simParam = SP_faba)
    
  }
  
  ##########################################
  
  
  if (year<6) {
    # Create Intercrop Trial: 784 Combinations (28x28)
    # trait2 is correlated trait in an intercrop setting
    
    pyt_trial = createIntercropTrial(F5_faba, F5_trit, reps= nreps_pyt, traitA=2, traitB=2, "ALL", h2_pyt)
    pyt_comb = as.data.frame(pyt_trial[["combinations_data"]])
    
    # Select Top Performers (intercrop_combinations)
    top_performers = selectTopPerformers(pyt_comb, ncomb_ayt )
    
    # Extract Top 8 Faba and Triticale Parents (from top combinations)
    
    speciesA_pyt= unique(top_performers$idA) %>% head(n = sqrt(ncomb_ayt))
    speciesB_pyt= unique(top_performers$idB) %>% head(n = sqrt(ncomb_ayt))
    # Create Intercrop Trial with Selected IDs (selecting ids  maintain formal pop format S4 class object)
    faba_pyt = F5_faba[F5_faba@id %in% speciesA_pyt]
    trit_pyt = F5_trit[F5_trit@id %in% speciesB_pyt]
  }
  
  if (year<7) {
    # Create Intercrop Trial with Selected IDs from intercrop trial with top performing faba and trit
    ayt_trial = createIntercropTrial(faba_pyt, trit_pyt, reps=nreps_ayt, traitA=2, traitB=2, "ALL", h2_ayt)
    ayt_comb = as.data.frame(ayt_trial[["combinations_data"]])
    
    # Select Top Performers
    top_performers = selectTopPerformers(ayt_comb, ncomb_eyt)
    
    # Extract Top 4 Faba and Triticale Parents to proceed for advance yield trials
    speciesA_ayt= unique(top_performers$idA) %>% head(n = sqrt(ncomb_eyt))
    speciesB_ayt= unique(top_performers$idB) %>% head(n = sqrt(ncomb_eyt))
    
    # Create Intercrop Trial with Selected IDs
    faba_ayt = faba_pyt[faba_pyt@id %in% speciesA_ayt]
    trit_ayt = trit_pyt[trit_pyt@id %in% speciesB_ayt]
  }
  
  
  if(year<8){
    # Create Intercrop Trial with Final Selection
    eyt_trial = createIntercropTrial(faba_ayt, trit_ayt,reps= nreps_eyt,traitA= 2,traitB= 2, "ALL",h2_eyt)
    eyt_comb = as.data.frame(eyt_trial[["combinations_data"]])
    
    
    
    # Select Top Performers
    top_performers = selectTopPerformers(eyt_comb, 36)
    
    # Extract Top 4 Faba and Triticale Parents to proceed for advance yield trials
    faba= unique(top_performers$idA) %>% head(n = 6)
    trit= unique(top_performers$idB) %>% head(n = 6) # refil parents  to next breeding
    faba_eyt = faba_ayt[faba_ayt@id %in% faba]
    trit_eyt = trit_ayt[trit_ayt@id %in% trit]
    
  }
  
  if (year<9){
    # Select the Top Performing combination
    final_combo = eyt_comb %>% arrange(desc(pheno_IC)) %>% head(n = 1)
  }
  
}

