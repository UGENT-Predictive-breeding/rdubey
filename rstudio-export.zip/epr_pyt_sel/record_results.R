cat("record_results\n")
 



#sole crop stage: gen val

#inter crop stage: genetic val
PYT_gv_ic[bc,] <-sapply(bc, function(bc) { mean(pyt_trial[["combinations_data"]][["gv_IC"]])})
AYT_gv_ic[bc,] <-sapply(bc, function(bc) { mean(ayt_trial[["combinations_data"]][["gv_IC"]])})
EYT_gv_ic[bc,] <-sapply(bc, function(bc) { mean(eyt_trial[["combinations_data"]][["gv_IC"]])})




#inter crop genetic val
PYT_pheno_ic[bc,] <-sapply(bc, function(bc) { mean(pyt_trial[["combinations_data"]][["pheno_IC"]])})
AYT_pheno_ic[bc,] <-sapply(bc, function(bc) { mean(ayt_trial[["combinations_data"]][["pheno_IC"]])})
EYT_pheno_ic[bc,] <-sapply(bc, function(bc) { mean(eyt_trial[["combinations_data"]][["pheno_IC"]])})



#var(pyt_trial[["combinations_data"]][["pheno_IC"]])

#intercrop genetic variance
PYT_varG_ic[bc,] <-sapply(bc, function(bc) {(var(pyt_trial[["combinations_data"]][["gv_IC"]]))})
AYT_varG_ic[bc,] <-sapply(bc, function(bc) {(var(ayt_trial[["combinations_data"]][["gv_IC"]]))})
EYT_varG_ic[bc,] <-sapply(bc, function(bc) {(var(eyt_trial[["combinations_data"]][["gv_IC"]]))})



#intercrop phenotypic variance
PYT_varP_ic[bc,] <-sapply(bc, function(bc) {(var(pyt_trial[["combinations_data"]][["pheno_IC"]]))})
AYT_varP_ic[bc,] <-sapply(bc, function(bc) {(var(ayt_trial[["combinations_data"]][["pheno_IC"]]))})
EYT_varP_ic[bc,] <-sapply(bc, function(bc) {(var(eyt_trial[["combinations_data"]][["pheno_IC"]]))})





# for (i in 1:length(bc)) {
#   genetic_data <- genParam(PYT, simParam = SP)
#   pyt_genetic_data[[as.character(bc[i])]] <- genetic_data
# }







