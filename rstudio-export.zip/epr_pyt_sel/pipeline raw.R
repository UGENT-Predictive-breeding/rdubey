

g_corr = c(1.0, 0.3, 0.3, 1.0)
h2_pyt = 0.1
h2_ayt = 0.2
h2_eyt = 0.3
plantsPerRow = 10
nRowF3 = 12
nRowF4 = 10
nRowF5 = 8
nRowF6 = 6
nCrosses_faba = 14
nCrosses_trit = 14
nProgenyF1 = 1
nProgenyF2 = 15
nProgenyF3 = 15
nProgenyF4 = 12
nProgenyF5 = 10
nProgenyF6 = 8



nselect_F1 = 1



nselect_F2 = 12
nselect_F3 = 15
nselect_F4 = 12
nselect_F5 = 10
nselect_F6 = 28
ncomb_ayt = 144
ncomb_eyt = 36
nreps_pyt = 1
nreps_ayt = 2
nreps_eyt = 4

# 
# #######n (Generation Number):
#   
#   This parameter specifies the current generation number for which the population is being generated. For instance, if n = 2, it means the function is working on generating the F2 generation.
#   
############## nCrosses (Number of Crosses):
#   
#   This is the number of different crosses or combinations of parental lines that you are working with in the current generation. Each cross can potentially produce a different set of offspring with varying characteristics.
#   
# ###############crop_name (Name of the Crop):
#   
#   This parameter is a string that represents the name of the crop species for which the breeding is being done. This could be any crop like 'wheat', 'corn', 'rice', etc. The crop name is used to construct the names of variables dynamically within the function.
#   
# ############nRowFn (Number of Rows to Select in Each Cross):
#   
#   After generating offspring from each cross, this parameter determines how many rows (or groups of plants) are selected based on their phenotypic performance. For example, if nRowFn = 10, the top 10 performing rows from each cross will be selected for further breeding steps.
#   
# ##############nselect_Fn (Number of Individuals to Select from Each Row):
#   
#   Once the top rows are selected as per nRowFn, this parameter specifies how many individual plants to select from each of these top-performing rows. It helps in narrowing down to the best-performing individuals.
#   
############### plantsPerRow (Number of Plants per Row):
#   
#   This parameter indicates how many plants are there in each row. It's used in the selfing process where each individual plant is self-fertilized to produce the next generation. This number affects the number of offspring each plant will produce.



for(year in 1:9){
  
  cat("epr_breeding:", year, "of 9\n")
  
  # Stage 1 - Initial Crosses (Year 1)
  if(year == 1){
    # Faba Bean: Random crosses for F1 generation
    F1_faba = randCross(pop = Par_faba_initial, nCrosses = nCrosses_faba, nProgeny = nProgenyF1, simParam = SP_faba)
    # Triticale: Random crosses for F1 generation
    F1_trit = randCross(pop = Par_trit_initial, nCrosses = nCrosses_trit, nProgeny = nProgenyF1, simParam = SP_trit)
  }
  
  # Stage 2 - F2 Generation (Year 2)
  if(year == 2){
    F2_faba = vector("list", nCrosses_faba)
    F2_trit = vector("list", nCrosses_trit)
    for(i in 1:nCrosses_faba){
      # Faba Bean: Selfing F1 and selecting individuals for F2
      F2_faba_i = self(F1_faba[i], nProgeny = 14,simParam = SP_faba )
      F2_faba_i = setPheno(F2_faba_i, h2 = 0.1, reps = 1,simParam = SP_faba)
      F2_faba[[i]] = selectOP(F2_faba_i, nInd = 10, nSeeds=10,probself=0.5, use="pheno",selectTop= TRUE, simParam = SP_faba)
    }
    for(i in 1:nCrosses_trit){
      # Triticale: Selfing F1 and selecting individuals for F2
      F2_trit_i = self(F1_trit[i], nProgeny = 14, simParam = SP_trit)
      F2_trit_i = setPheno(F2_trit_i,h2 = 0.1, reps = 1, simParam = SP_trit)
      F2_trit[[i]] = selectInd(F2_trit_i, nInd = 10, nSeeds=20,probself=0.5, use="pheno",selectTop= TRUE,  simParam = SP_trit)
    }
  
  }
  
  # Stage 3 - F3 Generation (Year 3)
  if(year == 3){
    F3_faba = gen_pop(3, nCrosses_faba, "faba", nRowFn=10, nselect_Fn=100, plantsPerRow=10, SP_faba)
    F3_trit = gen_pop(3, nCrosses_trit, "trit", nRowFn=10, nselect_Fn=100, plantsPerRow=20, SP_trit)
  }
  
  # Stage 4 - F4 Generation (Year 4)
  if(year == 4){
    F4_faba = gen_pop(4, nCrosses_faba, "faba", nRowFn=10, nselect_Fn=50, plantsPerRow=10, SP_faba)
    F4_trit = gen_pop(4, nCrosses_trit, "trit", nRowFn=10, nselect_Fn=50, plantsPerRow=10, SP_trit)
  }
  
  # Stage 5 - F5 Generation (Year 5)
  if(year == 5){
    F5_faba = gen_pop(5, nCrosses_faba, "faba", nRowFn=10, nselect_Fn=28, plantsPerRow=10, SP_faba)
    F5_trit = gen_pop(5, nCrosses_trit, "trit", nRowFn=10, nselect_Fn=28, plantsPerRow=10, SP_trit)
 
    
     }
  

  # Stage 6 - Intercrop Trial Creation and Selection
  if (year == 6) {
    # Create Intercrop Trial: 784 Combinations (28x28)
    pyt_trial = createIntercropTrial(F5_faba, F5_trit, reps = nreps_pyt, traitA = 2, traitB = 2, "ALL", h2_pyt)
    pyt_comb = as.data.frame(pyt_trial[["combinations_data"]])
    top_performers = selectTopPerformers(pyt_comb, ncomb_ayt)
    
    # Extract Top Parents
    speciesA_pyt = head(unique(top_performers$idA), n = sqrt(ncomb_ayt))
    speciesB_pyt = head(unique(top_performers$idB), n = sqrt(ncomb_ayt))
    
    # Create Intercrop Trial with Selected IDs
    faba_pyt = F5_faba[F5_faba@id %in% speciesA_pyt]
    trit_pyt = F5_trit[F5_trit@id %in% speciesB_pyt]
  }
  
  # Stage 7 - Advanced Intercrop Trial
  if (year == 7) {
    ayt_trial = createIntercropTrial(faba_pyt, trit_pyt, reps = nreps_ayt, traitA = 2, traitB = 2, "ALL", h2_ayt)
    ayt_comb = as.data.frame(ayt_trial[["combinations_data"]])
    top_performers = selectTopPerformers(ayt_comb, ncomb_eyt)
    
    # Extract Top Parents for Advanced Yield Trials
    speciesA_ayt = head(unique(top_performers$idA), n = sqrt(ncomb_eyt))
    speciesB_ayt = head(unique(top_performers$idB), n = sqrt(ncomb_eyt))
    
    faba_ayt = faba_pyt[faba_pyt@id %in% speciesA_ayt]
    trit_ayt = trit_pyt[trit_pyt@id %in% speciesB_ayt]
  }
  
  # Stage 8 - Final Intercrop Trial Selection
  if (year == 8) {
    eyt_trial = createIntercropTrial(faba_ayt, trit_ayt, reps = nreps_eyt, traitA = 2, traitB = 2, "ALL", h2_eyt)
    eyt_comb = as.data.frame(eyt_trial[["combinations_data"]])
    top_performers = selectTopPerformers(eyt_comb, 36)
    
    faba = head(unique(top_performers$idA), n = 6)
    trit = head(unique(top_performers$idB), n = 6)
    
    faba_eyt = faba_ayt[faba_ayt@id %in% faba]
    trit_eyt = trit_ayt[trit_ayt@id]
  }                     
}
