




if ("scenario" %in% ls()) {
  selection_stage <- scenario$selection_stage

  if (selection_stage == "pyt") {
    Par_faba <- faba_eyt
    Par_trit <- trit_eyt
  } else if (selection_stage == "ayt") {
    Par_faba <- faba_eyt
    Par_trit <- trit_eyt
  } else if (selection_stage == "eyt") {
    Par_faba <- faba_eyt
    Par_trit <- trit_eyt
  } else {
    # Handle the case when selection_stage is none of "pyt", "ayt", or "eyt"
    stop("Invalid value for selection_stage")
  }
} else {
  # 'scenario' data frame doesn't exist in the global environment
  stop("The 'scenario' data frame is not found in the global environment.")
}
