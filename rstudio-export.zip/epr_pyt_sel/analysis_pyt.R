

library(data.table)
library(dplyr)
library(ggplot2)

file_list <- list.files(path = "output/gv", pattern = "\\.csv$", full.names = TRUE, recursive = TRUE)

# Initialize empty lists to store individual data.frames for different columns
pyt_list <- list()
ayt_list <- list()
eyt_list <- list()

# Iterate through each file and extract the 'PYT_gv_ic', 'AYT', and 'EYT' columns
for (file in file_list) {
  dt <- fread(file)
  
  if ('PYT_gv_ic' %in% colnames(dt)) {
    pyt_list[[file]] <- dt[, .(PYT_gv_ic)]
  }
  
  if ('AYT_gv_ic' %in% colnames(dt)) {
    ayt_list[[file]] <- dt[, .(AYT_gv_ic)]
  }
  
  if ('EYT_gv_ic' %in% colnames(dt)) {
    eyt_list[[file]] <- dt[, .(EYT_gv_ic)]
  }
}

# Combine all extracted columns into a single data.table
result_pyt_dt <- data.frame(pyt_list)
result_ayt_dt <- data.frame(ayt_list)
result_eyt_dt <- data.frame(eyt_list)

pyt_GV= rowMeans(result_pyt_dt)
ayt_GV= rowMeans(result_ayt_dt)
eyt_GV = rowMeans(result_eyt_dt)

# Create a data.frame for plotting
plot_data <- data.frame(BREEDING_CYCLE = 1:20, PYT = pyt_GV, AYT = ayt_GV, EYT = eyt_GV)
library(ggplot2)

# Plot using ggplot2
p= ggplot(plot_data, aes(x = BREEDING_CYCLE)) +
  geom_line(aes(y = pyt_GV, color = "PYT"), size = 1) +
  geom_line(aes(y = ayt_GV, color = "AYT"), size = 1) +
  geom_line(aes(y = eyt_GV, color = "EYT"), size = 1) +
  scale_color_manual(values = c("red", "blue", "green"), labels = c("PYT", "AYT", "EYT"), name = "Breeding Stage") +  # Set color, labels, and legend title
  labs(title = "Selection at PYT stage", x = "Breeding cycle", y = "Intercrop GV") +  # Add labels to axes and title
  theme_minimal() +  # Use a minimal theme for aesthetics
  theme(legend.position = "bottom", plot.title = element_text(hjust = 0.5), panel.grid.major = element_line(color = "lightgray"), panel.grid.minor = element_blank())  # Adjust legend, center title, add gridlines

print(p)

###############################################################################################################################################
###############################################################################################################################################
###############################################################################################################################################



file_list <- list.files(path = "OUTPUT/varG", pattern = "\\.csv$", full.names = TRUE, recursive = TRUE)

# Initialize empty lists to store individual data.frames for different columns
pyt_varG_list <- list()
ayt_varG_list <- list()
eyt_varG_list <- list()

# Iterate through each file and extract the 'PYT_gv_ic', 'AYT', and 'EYT' columns
for (file in file_list) {
  dt <- fread(file)
  
  if ('PYT_varG_ic' %in% colnames(dt)) {
    pyt_varG_list[[file]] <- dt[, .(PYT_varG_ic)]
  }
  
  if ('AYT_varG_ic' %in% colnames(dt)) {
    ayt_varG_list[[file]] <- dt[, .(AYT_varG_ic)]
  }
  
  if ('EYT_varG_ic' %in% colnames(dt)) {
    eyt_varG_list[[file]] <- dt[, .(EYT_varG_ic)]
  }
}

# Combine all extracted columns into a single data.table
result_pyt_varG_dt <- data.frame(pyt_varG_list)
result_ayt_varG_dt <- data.frame(ayt_varG_list)
result_eyt_varG_dt <- data.frame(eyt_varG_list)

pyt_varG= rowMeans(result_pyt_varG_dt)
ayt_varG= rowMeans(result_ayt_varG_dt)
eyt_varG = rowMeans(result_eyt_varG_dt)

# Create a data.frame for plotting
plot_data <- data.frame(BREEDING_CYCLE = 1:30, PYT_gv_ic = pyt_varG, AYT = ayt_varG, EYT = eyt_varG)
library(ggplot2)


# Plot using ggplot2
Q= ggplot(plot_data, aes(x = BREEDING_CYCLE)) +
  geom_line(aes(y = pyt_varG, color = "PYT"), size = 1) +
  geom_line(aes(y = ayt_varG, color = "AYT"), size = 1) +
  geom_line(aes(y = eyt_varG, color = "EYT"), size = 1) +
  scale_color_manual(values = c("red", "blue", "green"), labels = c("PYT", "AYT", "EYT"), name = "Breeding Stage") +  # Set color, labels, and legend title
  labs(title = "Selection at PYT stage", x = "Breeding cycle", y = "Intercrop varG") +  # Add labels to axes and title
  theme_minimal() +  # Use a minimal theme for aesthetics
  theme(legend.position = "bottom", plot.title = element_text(hjust = 0.5), panel.grid.major = element_line(color = "lightgray"), panel.grid.minor = element_blank())  # Adjust legend, center title, add gridlines

print(Q)





