for(year in 1:9){
  
  cat("epr_breeding:", year, "of 9\n")
  
  # Stage 1 - Initial Crosses (Year 1)
  if(year== 1){
    # Faba Bean: Random crosses for F1 generation
    F1_faba = randCross(pop = Par_faba_initial, nCrosses = nCrosses_faba, nProgeny = nProgenyF1, simParam = SP_faba)
    # Triticale: Random crosses for F1 generation
    F1_trit = randCross(pop = Par_trit_initial, nCrosses = nCrosses_trit, nProgeny = nProgenyF1, simParam = SP_trit)
  }
  
  # Stage 2 - F2 Generation (Year 2)
  if(year== 2){
    F2_faba = vector("list", nCrosses_faba)
    F2_trit = vector("list", nCrosses_trit)
    for(i in 1:nCrosses_faba){
      # Faba Bean: Selfing F1 and selecting individuals for F2
      F2_faba_i = self(F1_faba[i], nProgeny = 14,simParam = SP_faba )
      F2_faba_i = setPheno(F2_faba_i, h2 = 0.1, reps = 1,simParam = SP_faba)
      F2_faba[[i]] = selectOP(F2_faba_i, nInd = 10, nSeeds=10,probself=0.5, use="pheno",selectTop= TRUE, simParam = SP_faba)
    }
    for(i in 1:nCrosses_trit){
      # Triticale: Selfing F1 and selecting individuals for F2
      F2_trit_i = self(F1_trit[i], nProgeny = 14, simParam = SP_trit)
      F2_trit_i = setPheno(F2_trit_i,h2 = 0.1, reps = 1, simParam = SP_trit)
      F2_trit[[i]] = selectInd(F2_trit_i, nInd = 10, nSeeds=20,probself=0.5, use="pheno",selectTop= TRUE,  simParam = SP_trit)
    }
    
  }
  
  # Stage 3 - F3 Generation (Year 3)
  if(year== 3){
    F3_faba = gen_pop(3, nCrosses_faba, "faba", nRowFn=5, nselect_Fn=10, plantsPerRow=10, SP_faba)
    F3_trit = gen_pop(3, nCrosses_trit, "trit", nRowFn=5, nselect_Fn=10, plantsPerRow=10, SP_trit)
  }
  
  # Stage 4 - F4 Generation (Year 4)
  if(year== 4){
    F4_faba = gen_pop(4, nCrosses_faba, "faba", nRowFn=5, nselect_Fn=5, plantsPerRow=10, SP_faba)
    F4_trit = gen_pop(4, nCrosses_trit, "trit", nRowFn=5, nselect_Fn=5, plantsPerRow=10, SP_trit)
  }
  
  # Stage 5 - F5 Generation (Year 5)
  if(year== 5){
    F5_faba = gen_pop(5, nCrosses_faba, "faba", nRowFn=5, nselect_Fn=2, plantsPerRow=10, SP_faba)
    F5_faba= mergePops(F5_faba)
    F5_faba= selectInd(F5_faba,nInd=28,trait=1, use="pheno"  ,selectTop = TRUE,returnPop = TRUE,simParam = SP_faba)
    
    
    F5_trit = gen_pop(5, nCrosses_trit, "trit", nRowFn=5, nselect_Fn=2, plantsPerRow=10, SP_trit)
    F5_trit = mergePops(F5_trit)
    F5_trit= selectInd(F5_faba,nInd=28,trait=1, use="pheno"  ,selectTop = TRUE,returnPop = TRUE,simParam = SP_trit)
    
  }
  # Stage 6 - Intercrop Trial Creation and Selection
  if (year== 6) {
    # Create Intercrop Trial: 784 Combinations (28x28)
    pyt_trial = createIntercropTrial(F5_faba, F5_trit, reps = nreps_pyt, traitA = 2, traitB = 2, "ALL", h2_pyt)
    pyt_comb = as.data.frame(pyt_trial[["combinations_data"]])
    top_performers = selectTopPerformers(pyt_comb, ncomb_ayt)
    
    # Extract Top Parents
    speciesA_pyt = head(unique(top_performers$idA), n = sqrt(ncomb_ayt))
    speciesB_pyt = head(unique(top_performers$idB), n = sqrt(ncomb_ayt))
    
    # Create Intercrop Trial with Selected IDs
    faba_pyt = F5_faba[F5_faba@id %in% speciesA_pyt]
    trit_pyt = F5_trit[F5_trit@id %in% speciesB_pyt]
  }
  
  # Stage 7 - Advanced Intercrop Trial
  if (year== 7) {
    ayt_trial = createIntercropTrial(faba_pyt, trit_pyt, reps = nreps_ayt, traitA = 2, traitB = 2, "ALL", h2_ayt)
    ayt_comb = as.data.frame(ayt_trial[["combinations_data"]])
    top_performers = selectTopPerformers(ayt_comb, ncomb_eyt)
    
    # Extract Top Parents for Advanced Yield Trials
    speciesA_ayt = head(unique(top_performers$idA), n = sqrt(ncomb_eyt))
    speciesB_ayt = head(unique(top_performers$idB), n = sqrt(ncomb_eyt))
    
    faba_ayt = faba_pyt[faba_pyt@id %in% speciesA_ayt]
    trit_ayt = trit_pyt[trit_pyt@id %in% speciesB_ayt]
  }
  
  # Stage 8 - Final Intercrop Trial Selection
  if (year== 8) {
    eyt_trial = createIntercropTrial(faba_ayt, trit_ayt, reps = nreps_eyt, traitA = 2, traitB = 2, "ALL", h2_eyt)
    eyt_comb = as.data.frame(eyt_trial[["combinations_data"]])
    top_performers = selectTopPerformers(eyt_comb, 36)
    
    faba = head(unique(top_performers$idA), n = 6)
    trit = head(unique(top_performers$idB), n = 6)
    
    faba_eyt = faba_ayt[faba_ayt@id %in% faba]
    trit_eyt = trit_ayt[trit_ayt@id]
  }                     
}
