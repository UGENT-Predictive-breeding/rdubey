rm(list = ls())
start_time <- Sys.time()
setwd("/data/home/rdubey/MIB approach/MIB/dh_breeding/Selection_stage/epr_pyt_sel/")

set.seed(123)
#load libraries 
libraries <- c("AlphaSimR", "tibble", "ggplot2", "tidyr", "data.table",
               "dplyr", "ggrepel", "MASS", "condMVNorm", "plotly",
               "writexl", "readxl")

#load functions
source("functions_.R")
source ("Scenarios.R") #load all scenariosa
#Variables to record
PYT_gv_ic = AYT_gv_ic = EYT_gv_ic = Var_gv_ic= PYT_pheno_ic = AYT_pheno_ic = EYT_pheno_ic =Var_pheno_ic =PYT_varP_ic = AYT_varP_ic = EYT_varP_ic=Var_varP_ic = PYT_varG_ic = AYT_varG_ic = EYT_varG_ic =Var_varG_ic =matrix(NA, nrow = 20, ncol = 1)


# Loop over scenarios
for (scenario in scenarios) {
  for (seed in 1:100) { # seeds to run the script n times
  
    g_corr <- scenario$g_corr
    h2_pyt <- scenario$h2_pyt
    h2_ayt <- scenario$h2_ayt
    h2_eyt <- scenario$h2_eyt
    plantsPerRow <- scenario$plantsPerRow
    nRowFn <- scenario$nRowFn
    nCrosses_faba <- scenario$nCrosses_faba
    nCrosses_trit <- scenario$nCrosses_trit
    nProgenyF1 <- scenario$nProgenyF1
    nselect_F3 <- scenario$nselect_F3
    nselect_F4 <- scenario$nselect_F4
    nselect_F5 <- scenario$nselect_F5
    ncomb_ayt <- scenario$ncomb_ayt
    ncomb_eyt <- scenario$ncomb_eyt
    nreps_pyt <- scenario$nreps_pyt
    nreps_ayt <- scenario$nreps_ayt
    nreps_eyt <- scenario$nreps_eyt
    path_gv <- scenario$path_gv
    path_pheno <- scenario$path_pheno
    path_varP <- scenario$path_varP
    path_varG <- scenario$path_varG
    selection_stage <- scenario$selection_stage
   
    
    
    main_folder_path = paste0("/data/home/rdubey/MIB approach/MIB/dh_breeding/Selection_stage/epr_pyt_sel/", scenario$trait_type, "output/", scenario$output_name, "/")
  
  # Create the main folder if it doesn't exist
  dir.create(main_folder_path, recursive = TRUE, showWarnings = FALSE)
  
  # Construct subfolder paths based on the main folder
  path_gv = paste0(main_folder_path, "gv/")
  path_pheno = paste0(main_folder_path, "pheno/")
  path_varP = paste0(main_folder_path, "varP/")
  path_varG = paste0(main_folder_path, "varG/")
  
  # Create subfolders inside the main folder
  dir.create(path_gv, recursive = TRUE, showWarnings = FALSE)
  dir.create(path_pheno, recursive = TRUE, showWarnings = FALSE)
  dir.create(path_varP, recursive = TRUE, showWarnings = FALSE)
  dir.create(path_varG, recursive = TRUE, showWarnings = FALSE)
    
    
    
    
    
    source("simulate_founder.R") # simulate founder pop and set population parameters
    source("eprbreeding_simplified.R") # fill initial pipeline
    
    # i=breeding cycle
    for (bc in 1:20) {
      
      cat("Working on seed:", seed, " - breeding cycle:", bc, "\n")
      source("refill_parents.R")
      source("next_breeding.R")
      source("record_results.R")
      source("output.R")
      
    }

  
    }

  
  }


#source("analysis.R")

# Record end time
end_time <- Sys.time()

# Calculate and print the duration
duration <- end_time - start_time
